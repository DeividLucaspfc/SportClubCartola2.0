<?php

  session_start();

  require_once ('conexao.php');
  

  if (!isset($_SESSION['nome'])){
    header("location: login.php");
  }
  else if ($_SESSION['situacao'] == "inativo"){
    header("location: inativo.php");
  } 
  
  else {
  ?> <h1 class="login"> Olá <?php echo $_SESSION['nome']; ?>! Bem vindo ao manager 2020!!! </h1>  <?php
  }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>4-3-3</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Sport Club Cartola, Desenvolvimento de Jogos e Campeonatos.">
    <meta name="keywords" content="cartola, campeonatos, manager, sites">
    <meta name="robots" content= "index, follow">
    <link href="https://fonts.googleapis.com/css?family=Cairo&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="4_3_3.css">
    <script src="direciona.js"></script>
</head>
<body>
<?php require_once 'header.php';
  $time = $_SESSION['time'];
  //Verifique se esses dados já estão no DB
  $consulta = "SELECT * FROM escalacoes WHERE timef='{$time}'";
  $connect = $conn->query($consulta) or die ($conn->error);
  $dado = $connect->fetch_array();

  if (isset($dado['timef'])){
  ?>

    <div class="corpo_form-cad">
    <h1>TIME JÁ ESCALADO</h1>
    <form method="POST" action="process_escal.php">
      <img class="campo_escalacao" src="img/campo_escalacao.png" alt="campo">
      <div class="escalacao_completa">
        <p>
          <select name="jog1" class="jog1" required>
            <option value="" selected="selected"></option>
            <option value="Agenor (FLU)">Agenor (FLU)</option>
            <option value="Brenno (GRE)">Brenno (GRE)</option>
            <option value="Caíque França (COR)">Caíque França (COR)</option>
            <option value="Cassio (COR)">Cassio (COR)</option>
            <option value="Cesar (FLA)">Cesar (FLA)</option>
            <option value="Cleiton (CAM)">Cleiton (CAM)</option>
            <option value="Daniel (INT)">Daniel (INT)</option>
            <option value="Danilo Fernandes (INT)">Danilo Fernandes (INT)</option>
            <option value="Diego (BOT)">Diego (BOT)</option>
            <option value="Diego Alves (FLA)">Diego Alves (FLA)</option>
            <option value="Diego Cavalieri (BOT)">Diego Cavalieri (BOT)</option>
            <option value="Fabio (CRU)">Fabio (CRU)</option>
            <option value="Fernando (CAM)">Fernando (CAM)</option>
            <option value="Fernando Miguel (VAS)">Fernando Miguel (VAS)</option>
            <option value="Fernando Prass (PAL)">Fernando Prass (PAL)</option>
            <option value="Filipe (COR)">Filipe (COR)</option>
            <option value="Gabriel Batista (FLA)">Gabriel Batista (FLA)</option>
            <option value="Gabriel Brazao (CRU)">Gabriel Brazao (CRU)</option>
            <option value="Gabriel Felix (VAS)">Gabriel Felix (VAS)</option>
            <option value="Gatito Fernandez (BOT)">Gatito Fernandez (BOT)</option>
            <option value="Jailson (PAL)">Jailson (PAL)</option>
            <option value="Jean (SAO)">Jean (SAO)</option>
            <option value="Joao Paulo (SAN)">Joao Paulo (SAN)</option>
            <option value="Joao Pedro (VAS)">Joao Pedro (VAS)</option>
            <option value="John (SAN)">John (SAN)</option>
            <option value="Jordi (VAS)">Jordi (VAS)</option>
            <option value="Julio Cesar (GRE)">Julio Cesar (GRE)</option>
            <option value="Júnior (SAO)">Júnior (SAO)</option>
            <option value="Keiller (INT)">Keiller (INT)</option>
            <option value="Marcelo Lomba (INT)">Marcelo Lomba (INT)</option>
            <option value="Marcos Felipe (FLU)">Marcos Felipe (FLU)</option>
            <option value="Matheus Donelli (COR)">Matheus Donelli (COR)</option>
            <option value="Michael (CAM)">Michael (CAM)</option>
            <option value="Paulo Victor (GRE)">Paulo Victor (GRE)</option>
            <option value="Rafael (CRU)">Rafael (CRU)</option>
            <option value="Rodolfo (FLU)">Rodolfo (FLU)</option>
            <option value="Tiago Volpi (SAO)">Tiago Volpi (SAO)</option>
            <option value="Uilson (CAM)">Uilson (CAM)</option>
            <option value="Vanderlei (SAN)">Vanderlei (SAN)</option>
            <option value="Victor (CAM)">Victor (CAM)</option>
            <option value="Vitor Eudes (CRU)">Vitor Eudes (CRU)</option>
            <option value="Vladimir (SAN)">Vladimir (SAN)</option>
            <option value="Walter (COR)">Walter (COR)</option>
            <option value="Weverton (PAL)">Weverton (PAL)</option>
          </select>
        </p>
          
        <p>
          <select name="jog2" class="jog2" required>
            <option value="" selected="selected"></option>
            <option value="B. Alves (SAO)">B. Alves (SÃO)</option>
            <option value="Cuesta (INT)" >Cuesta (INT)</option>
            <option value="G. Henrique (SAN)" >G. Henrique (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog3" class="jog3" required>
            <option value="" selected="selected"></option>
            <option value="B. Alves (SAO)">B. Alves (SÃO)</option>
            <option value="Cuesta (INT)" >Cuesta (INT)</option>
            <option value="G. Henrique (SAN)" >G. Henrique (SAN)</option>
          </select>
        </p>
        
        <p>
          <select name="jog4" class="jog4" required>
            <option value="" selected="selected"></option>
            <option value="D. Alves (SAO)">D. Alves (SÃO)</option>
            <option value="Bruno (INT)">Bruno (INT)</option>
            <option value="V. Ferraz (SAN)" >V. Ferraz (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog5" class="jog5" required>
            <option value="" selected="selected"></option>
            <option value="D. Alves (SAO)">D. Alves (SÃO)</option>
            <option value="Bruno (INT)">Bruno (INT)</option>
            <option value="V. Ferraz (SAN)">V. Ferraz (SAN)</option>
          </select>
        </p>
        
        <p>
          <select name="jog6" class="jog6" required>
            <option value="" selected="selected"></option>
            <option value="" selected="selected"></option>
            <option value="Adilson (CAM)">Adilson (CAM)</option>
            <option value="Airton (FLU)">Airton (FLU)</option>
            <option value="Alan Santos (BOT)">Alan Santos (BOT)</option>
            <option value="Alex Santana (BOT)">Alex Santana (BOT)</option>
            <option value="Alison (SAN)">Alison (SAN)</option>
            <option value="Anderson Ceara (SAN)">Anderson Ceara (SAN)</option>
            <option value="Andrey (VAS)">Andrey (VAS)</option>
            <option value="Araos (COR)">Araos (COR)</option>
            <option value="Araruna (SAO)">Araruna (SAO)</option>
            <option value="Ariel Cabral (CRU)">Ariel Cabral (CRU)</option>
            <option value="Bruninho (CAM)">Bruninho (CAM)</option>
            <option value="Bruno Cesar (VAS)">Bruno Cesar (VAS)</option>
            <option value="Bruno Henrique (PAL)">Bruno Henrique (PAL)</option>
            <option value="Bruno Ritter (VAS)">Bruno Ritter (VAS)</option>
            <option value="Bruno Silva (FLU)">Bruno Silva (FLU)</option>
            <option value="Bruno Silva (VAS)">Bruno Silva (VAS)</option>
            <option value="Bryan Ruiz (SAN)">Bryan Ruiz (SAN)</option>
            <option value="Caio (FLU)">Caio (FLU)</option>
            <option value="Caio Henrique (FLU)">Caio Henrique (FLU)</option>
            <option value="Camilo (INT)">Camilo (INT)</option>
            <option value="Carlos Sanchez (SAN)">Carlos Sanchez (SAN)</option>
            <option value="Cazares (CAM)">Cazares (CAM)</option>
            <option value="Charles (INT)">Charles (INT)</option>
            <option value="Cuellar (FLA)">Cuellar (FLA)</option>
            <option value="D'Alessandro (INT)">D'Alessandro (INT)</option>
            <option value="Danielzinho (FLU)">Danielzinho (FLU)</option>
            <option value="David Terans (CAM)">David Terans (CAM)</option>
            <option value="De Arrascaeta (FLA)">De Arrascaeta (FLA)</option>
            <option value="Denilson (FLU)">Denilson (FLU)</option>
            <option value="Diego (FLA)">Diego (FLA)</option>
            <option value="Diego Pituca (SAN)">Diego Pituca (SAN)</option>
            <option value="Dodi (FLU)">Dodi (FLU)</option>
            <option value="Dodô (CAM)">Dodô (CAM)</option>
            <option value="Douglas (COR)">Douglas (COR)</option>
            <option value="Dudu (VAS)">Dudu (VAS)</option>
            <option value="Edenilson (INT)">Edenilson (INT)</option>
            <option value="Éderson (CRU)">Éderson (CRU)</option>
            <option value="Elias (CAM)">Elias (CAM)</option>
            <option value="Everton Felipe (SAO)">Everton Felipe (SAO)</option>
            <option value="Éverton Ribeiro (FLA)">Éverton Ribeiro (FLA)</option>
            <option value="Felipe Melo (PAL)">Felipe Melo (PAL)</option>
            <option value="Fellipe Bastos (VAS)">Fellipe Bastos (VAS)</option>
            <option value="Gabriel (COR)">Gabriel (COR)</option>
            <option value="Gabriel Calabres (SAN)">Gabriel Calabres (SAN)</option>
            <option value="Guerra (PAL)">Guerra (PAL)</option>
            <option value="Guilherme Costa (VAS)">Guilherme Costa (VAS)</option>
            <option value="Guilherme Nunes (SAN)">Guilherme Nunes (SAN)</option>
            <option value="Gustavo Blanco (CAM)">Gustavo Blanco (CAM)</option>
            <option value="Gustavo Bochecha (BOT)">Gustavo Bochecha (BOT)</option>
            <option value="Gustavo Ferrareis (BOT)">Gustavo Ferrareis (BOT)</option>
            <option value="Gustavo Scarpa (PAL)">Gustavo Scarpa (PAL)</option>
            <option value="Henrique (CRU)">Henrique (CRU)</option>
            <option value="Hernanes (SAO)">Hernanes (SAO)</option>
            <option value="Hudson (SAO)">Hudson (SAO)</option>
            <option value="Hugo Moura (FLA)">Hugo Moura (FLA)</option>
            <option value="Hyoran (PAL)">Hyoran (PAL)</option>
            <option value="Igor Gomes (SAO)">Igor Gomes (SAO)</option>
            <option value="Jadson (COR)">Jadson (COR)</option>
            <option value="Jadson (CRU)">Jadson (CRU)</option>
            <option value="Jair (CAM)">Jair (CAM)</option>
            <option value="Jean (BOT)">Jean (BOT)</option>
            <option value="Jean Lucas (FLA)">Jean Lucas (FLA)</option>
            <option value="Jean Pyerre (GRE)">Jean Pyerre (GRE)</option>
            <option value="Joao Paulo (BOT)">Joao Paulo (BOT)</option>
            <option value="Jose Welison (CAM)">Jose Welison (CAM)</option>
            <option value="Juan Alano (INT)">Juan Alano (INT)</option>
            <option value="Jucilei (SAO)">Jucilei (SAO)</option>
            <option value="Kaio (GRE)">Kaio (GRE)</option>
            <option value="Lincoln (GRE)">Lincoln (GRE)</option>
            <option value="Liziero (SAO)">Liziero (SAO)</option>
            <option value="Luan (SAO)">Luan (SAO)</option>
            <option value="Lucas Braga (SAN)">Lucas Braga (SAN)</option>
            <option value="Lucas Cândido (CAM)">Lucas Cândido (CAM)</option>
            <option value="Lucas Lima (PAL)">Lucas Lima (PAL)</option>
            <option value="Lucas Mineiro (VAS)">Lucas Mineiro (VAS)</option>
            <option value="Lucas Romero (CRU)">Lucas Romero (CRU)</option>
            <option value="Lucas Santos (VAS)">Lucas Santos (VAS)</option>
            <option value="Lucas Silva (CRU)">Lucas Silva (CRU)</option>
            <option value="Luiz Fernando (BOT)">Luiz Fernando (BOT)</option>
            <option value="Luiz Fernando (FLU)">Luiz Fernando (FLU)</option>
            <option value="Maicon (GRE)">Maicon (GRE)</option>
            <option value="Marcelo Mattos (VAS)">Marcelo Mattos (VAS)</option>
            <option value="Marcos Vinicius (BOT)">Marcos Vinicius (BOT)</option>
            <option value="Marquinhos (COR)">Marquinhos (COR)</option>
            <option value="Marquinhos (COR)">Marquinhos (COR)</option>
            <option value="Mateus Vital (COR)">Mateus Vital (COR)</option>
            <option value="Matheus Fernandes (PAL)">Matheus Fernandes (PAL)</option>
            <option value="Matheus Galdezani (INT)">Matheus Galdezani (INT)</option>
            <option value="Matheus Henrique (GRE)">Matheus Henrique (GRE)</option>
            <option value="Michel (GRE)">Michel (GRE)</option>
            <option value="Moises (PAL)">Moises (PAL)</option>
            <option value="Montoya (GRE)">Montoya (GRE)</option>
            <option value="Nathan (CAM)">Nathan (CAM)</option>
            <option value="Nene (SAO)">Nene (SAO)</option>
            <option value="Patrick (INT)">Patrick (INT)</option>
            <option value="Pedrinho (COR)">Pedrinho (COR)</option>
            <option value="Piris da Motta (FLA)">Piris da Motta (FLA)</option>
            <option value="Rafael Bilu (COR)">Rafael Bilu (COR)</option>
            <option value="Rafinha (CRU)">Rafinha (CRU)</option>
            <option value="Ralf (COR)">Ralf (COR)</option>
            <option value="Ramiro (COR)">Ramiro (COR)</option>
            <option value="Raphael Veiga (PAL)">Raphael Veiga (PAL)</option>
            <option value="Raul (VAS)">Raul (VAS)</option>
            <option value="Rene Junior (COR)">Rene Junior (COR)</option>
            <option value="Richard (COR)">Richard (COR)</option>
            <option value="Richard (INT)">Richard (INT)</option>
            <option value="Rickson (BOT)">Rickson (BOT)</option>
            <option value="Rithely (INT)">Rithely (INT)</option>
            <option value="Robinho (CRU)">Robinho (CRU)</option>
            <option value="Rodrigo Dourado (INT)">Rodrigo Dourado (INT)</option>
            <option value="Rodrigo Fernandes (VAS)">Rodrigo Fernandes (VAS)</option>
            <option value="Rodrigo Lindoso (INT)">Rodrigo Lindoso (INT)</option>
            <option value="Romulo (GRE)">Romulo (GRE)</option>
            <option value="Ronaldo (FLA)">Ronaldo (FLA)</option>
            <option value="Sarrafiore (INT)">Sarrafiore (INT)</option>
            <option value="Sornoza (COR)">Sornoza (COR)</option>
            <option value="Soteldo (SAN)">Soteldo (SAN)</option>
            <option value="Thaciano (GRE)">Thaciano (GRE)</option>
            <option value="Thiago Galhardo (VAS)">Thiago Galhardo (VAS)</option>
            <option value="Thiago Neves (CRU)">Thiago Neves (CRU)</option>
            <option value="Thiago Santos (PAL)">Thiago Santos (PAL)</option>
            <option value="Thiaguinho (COR)">Thiaguinho (COR)</option>
            <option value="Thonny Anderson (GRE)">Thonny Anderson (GRE)</option>
            <option value="Valdivia (INT)">Valdivia (INT)</option>
            <option value="Valencia (BOT)">Valencia (BOT)</option>
            <option value="Vinícius (CAM)">Vinícius (CAM)</option>
            <option value="Wenderson (BOT)">Wenderson (BOT)</option>
            <option value="Willian Arao (FLA)">Willian Arao (FLA)</option>
            <option value="Willian Farias (SAO)">Willian Farias (SAO)</option>
            <option value="Willian Maranhao (VAS)">Willian Maranhao (VAS)</option>
            <option value="Yan Sasse (VAS)">Yan Sasse (VAS)</option>
            <option value="Yuri (SAN)">Yuri (SAN)</option>
            <option value="Ze Rafael (PAL)">Ze Rafael (PAL)</option>
            <option value="Ze Ricardo (FLU)">Ze Ricardo (FLU)</option>
          </select>
        </p>
        <p>
          <select name="jog7" class="jog7" required>
            <option value="" selected="selected" ></option>
            <option value="" selected="selected"></option>
            <option value="Adilson (CAM)">Adilson (CAM)</option>
            <option value="Airton (FLU)">Airton (FLU)</option>
            <option value="Alan Santos (BOT)">Alan Santos (BOT)</option>
            <option value="Alex Santana (BOT)">Alex Santana (BOT)</option>
            <option value="Alison (SAN)">Alison (SAN)</option>
            <option value="Anderson Ceara (SAN)">Anderson Ceara (SAN)</option>
            <option value="Andrey (VAS)">Andrey (VAS)</option>
            <option value="Araos (COR)">Araos (COR)</option>
            <option value="Araruna (SAO)">Araruna (SAO)</option>
            <option value="Ariel Cabral (CRU)">Ariel Cabral (CRU)</option>
            <option value="Bruninho (CAM)">Bruninho (CAM)</option>
            <option value="Bruno Cesar (VAS)">Bruno Cesar (VAS)</option>
            <option value="Bruno Henrique (PAL)">Bruno Henrique (PAL)</option>
            <option value="Bruno Ritter (VAS)">Bruno Ritter (VAS)</option>
            <option value="Bruno Silva (FLU)">Bruno Silva (FLU)</option>
            <option value="Bruno Silva (VAS)">Bruno Silva (VAS)</option>
            <option value="Bryan Ruiz (SAN)">Bryan Ruiz (SAN)</option>
            <option value="Caio (FLU)">Caio (FLU)</option>
            <option value="Caio Henrique (FLU)">Caio Henrique (FLU)</option>
            <option value="Camilo (INT)">Camilo (INT)</option>
            <option value="Carlos Sanchez (SAN)">Carlos Sanchez (SAN)</option>
            <option value="Cazares (CAM)">Cazares (CAM)</option>
            <option value="Charles (INT)">Charles (INT)</option>
            <option value="Cuellar (FLA)">Cuellar (FLA)</option>
            <option value="D'Alessandro (INT)">D'Alessandro (INT)</option>
            <option value="Danielzinho (FLU)">Danielzinho (FLU)</option>
            <option value="David Terans (CAM)">David Terans (CAM)</option>
            <option value="De Arrascaeta (FLA)">De Arrascaeta (FLA)</option>
            <option value="Denilson (FLU)">Denilson (FLU)</option>
            <option value="Diego (FLA)">Diego (FLA)</option>
            <option value="Diego Pituca (SAN)">Diego Pituca (SAN)</option>
            <option value="Dodi (FLU)">Dodi (FLU)</option>
            <option value="Dodô (CAM)">Dodô (CAM)</option>
            <option value="Douglas (COR)">Douglas (COR)</option>
            <option value="Dudu (VAS)">Dudu (VAS)</option>
            <option value="Edenilson (INT)">Edenilson (INT)</option>
            <option value="Éderson (CRU)">Éderson (CRU)</option>
            <option value="Elias (CAM)">Elias (CAM)</option>
            <option value="Everton Felipe (SAO)">Everton Felipe (SAO)</option>
            <option value="Éverton Ribeiro (FLA)">Éverton Ribeiro (FLA)</option>
            <option value="Felipe Melo (PAL)">Felipe Melo (PAL)</option>
            <option value="Fellipe Bastos (VAS)">Fellipe Bastos (VAS)</option>
            <option value="Gabriel (COR)">Gabriel (COR)</option>
            <option value="Gabriel Calabres (SAN)">Gabriel Calabres (SAN)</option>
            <option value="Guerra (PAL)">Guerra (PAL)</option>
            <option value="Guilherme Costa (VAS)">Guilherme Costa (VAS)</option>
            <option value="Guilherme Nunes (SAN)">Guilherme Nunes (SAN)</option>
            <option value="Gustavo Blanco (CAM)">Gustavo Blanco (CAM)</option>
            <option value="Gustavo Bochecha (BOT)">Gustavo Bochecha (BOT)</option>
            <option value="Gustavo Ferrareis (BOT)">Gustavo Ferrareis (BOT)</option>
            <option value="Gustavo Scarpa (PAL)">Gustavo Scarpa (PAL)</option>
            <option value="Henrique (CRU)">Henrique (CRU)</option>
            <option value="Hernanes (SAO)">Hernanes (SAO)</option>
            <option value="Hudson (SAO)">Hudson (SAO)</option>
            <option value="Hugo Moura (FLA)">Hugo Moura (FLA)</option>
            <option value="Hyoran (PAL)">Hyoran (PAL)</option>
            <option value="Igor Gomes (SAO)">Igor Gomes (SAO)</option>
            <option value="Jadson (COR)">Jadson (COR)</option>
            <option value="Jadson (CRU)">Jadson (CRU)</option>
            <option value="Jair (CAM)">Jair (CAM)</option>
            <option value="Jean (BOT)">Jean (BOT)</option>
            <option value="Jean Lucas (FLA)">Jean Lucas (FLA)</option>
            <option value="Jean Pyerre (GRE)">Jean Pyerre (GRE)</option>
            <option value="Joao Paulo (BOT)">Joao Paulo (BOT)</option>
            <option value="Jose Welison (CAM)">Jose Welison (CAM)</option>
            <option value="Juan Alano (INT)">Juan Alano (INT)</option>
            <option value="Jucilei (SAO)">Jucilei (SAO)</option>
            <option value="Kaio (GRE)">Kaio (GRE)</option>
            <option value="Lincoln (GRE)">Lincoln (GRE)</option>
            <option value="Liziero (SAO)">Liziero (SAO)</option>
            <option value="Luan (SAO)">Luan (SAO)</option>
            <option value="Lucas Braga (SAN)">Lucas Braga (SAN)</option>
            <option value="Lucas Cândido (CAM)">Lucas Cândido (CAM)</option>
            <option value="Lucas Lima (PAL)">Lucas Lima (PAL)</option>
            <option value="Lucas Mineiro (VAS)">Lucas Mineiro (VAS)</option>
            <option value="Lucas Romero (CRU)">Lucas Romero (CRU)</option>
            <option value="Lucas Santos (VAS)">Lucas Santos (VAS)</option>
            <option value="Lucas Silva (CRU)">Lucas Silva (CRU)</option>
            <option value="Luiz Fernando (BOT)">Luiz Fernando (BOT)</option>
            <option value="Luiz Fernando (FLU)">Luiz Fernando (FLU)</option>
            <option value="Maicon (GRE)">Maicon (GRE)</option>
            <option value="Marcelo Mattos (VAS)">Marcelo Mattos (VAS)</option>
            <option value="Marcos Vinicius (BOT)">Marcos Vinicius (BOT)</option>
            <option value="Marquinhos (COR)">Marquinhos (COR)</option>
            <option value="Marquinhos (COR)">Marquinhos (COR)</option>
            <option value="Mateus Vital (COR)">Mateus Vital (COR)</option>
            <option value="Matheus Fernandes (PAL)">Matheus Fernandes (PAL)</option>
            <option value="Matheus Galdezani (INT)">Matheus Galdezani (INT)</option>
            <option value="Matheus Henrique (GRE)">Matheus Henrique (GRE)</option>
            <option value="Michel (GRE)">Michel (GRE)</option>
            <option value="Moises (PAL)">Moises (PAL)</option>
            <option value="Montoya (GRE)">Montoya (GRE)</option>
            <option value="Nathan (CAM)">Nathan (CAM)</option>
            <option value="Nene (SAO)">Nene (SAO)</option>
            <option value="Patrick (INT)">Patrick (INT)</option>
            <option value="Pedrinho (COR)">Pedrinho (COR)</option>
            <option value="Piris da Motta (FLA)">Piris da Motta (FLA)</option>
            <option value="Rafael Bilu (COR)">Rafael Bilu (COR)</option>
            <option value="Rafinha (CRU)">Rafinha (CRU)</option>
            <option value="Ralf (COR)">Ralf (COR)</option>
            <option value="Ramiro (COR)">Ramiro (COR)</option>
            <option value="Raphael Veiga (PAL)">Raphael Veiga (PAL)</option>
            <option value="Raul (VAS)">Raul (VAS)</option>
            <option value="Rene Junior (COR)">Rene Junior (COR)</option>
            <option value="Richard (COR)">Richard (COR)</option>
            <option value="Richard (INT)">Richard (INT)</option>
            <option value="Rickson (BOT)">Rickson (BOT)</option>
            <option value="Rithely (INT)">Rithely (INT)</option>
            <option value="Robinho (CRU)">Robinho (CRU)</option>
            <option value="Rodrigo Dourado (INT)">Rodrigo Dourado (INT)</option>
            <option value="Rodrigo Fernandes (VAS)">Rodrigo Fernandes (VAS)</option>
            <option value="Rodrigo Lindoso (INT)">Rodrigo Lindoso (INT)</option>
            <option value="Romulo (GRE)">Romulo (GRE)</option>
            <option value="Ronaldo (FLA)">Ronaldo (FLA)</option>
            <option value="Sarrafiore (INT)">Sarrafiore (INT)</option>
            <option value="Sornoza (COR)">Sornoza (COR)</option>
            <option value="Soteldo (SAN)">Soteldo (SAN)</option>
            <option value="Thaciano (GRE)">Thaciano (GRE)</option>
            <option value="Thiago Galhardo (VAS)">Thiago Galhardo (VAS)</option>
            <option value="Thiago Neves (CRU)">Thiago Neves (CRU)</option>
            <option value="Thiago Santos (PAL)">Thiago Santos (PAL)</option>
            <option value="Thiaguinho (COR)">Thiaguinho (COR)</option>
            <option value="Thonny Anderson (GRE)">Thonny Anderson (GRE)</option>
            <option value="Valdivia (INT)">Valdivia (INT)</option>
            <option value="Valencia (BOT)">Valencia (BOT)</option>
            <option value="Vinícius (CAM)">Vinícius (CAM)</option>
            <option value="Wenderson (BOT)">Wenderson (BOT)</option>
            <option value="Willian Arao (FLA)">Willian Arao (FLA)</option>
            <option value="Willian Farias (SAO)">Willian Farias (SAO)</option>
            <option value="Willian Maranhao (VAS)">Willian Maranhao (VAS)</option>
            <option value="Yan Sasse (VAS)">Yan Sasse (VAS)</option>
            <option value="Yuri (SAN)">Yuri (SAN)</option>
            <option value="Ze Rafael (PAL)">Ze Rafael (PAL)</option>
            <option value="Ze Ricardo (FLU)">Ze Ricardo (FLU)</option>
          </select>
        </p>
        <p>
          <select name="jog8" class="jog8" required>
            <option value="" selected="selected"></option>
            <option value="" selected="selected"></option>
            <option value="Adilson (CAM)">Adilson (CAM)</option>
            <option value="Airton (FLU)">Airton (FLU)</option>
            <option value="Alan Santos (BOT)">Alan Santos (BOT)</option>
            <option value="Alex Santana (BOT)">Alex Santana (BOT)</option>
            <option value="Alison (SAN)">Alison (SAN)</option>
            <option value="Anderson Ceara (SAN)">Anderson Ceara (SAN)</option>
            <option value="Andrey (VAS)">Andrey (VAS)</option>
            <option value="Araos (COR)">Araos (COR)</option>
            <option value="Araruna (SAO)">Araruna (SAO)</option>
            <option value="Ariel Cabral (CRU)">Ariel Cabral (CRU)</option>
            <option value="Bruninho (CAM)">Bruninho (CAM)</option>
            <option value="Bruno Cesar (VAS)">Bruno Cesar (VAS)</option>
            <option value="Bruno Henrique (PAL)">Bruno Henrique (PAL)</option>
            <option value="Bruno Ritter (VAS)">Bruno Ritter (VAS)</option>
            <option value="Bruno Silva (FLU)">Bruno Silva (FLU)</option>
            <option value="Bruno Silva (VAS)">Bruno Silva (VAS)</option>
            <option value="Bryan Ruiz (SAN)">Bryan Ruiz (SAN)</option>
            <option value="Caio (FLU)">Caio (FLU)</option>
            <option value="Caio Henrique (FLU)">Caio Henrique (FLU)</option>
            <option value="Camilo (INT)">Camilo (INT)</option>
            <option value="Carlos Sanchez (SAN)">Carlos Sanchez (SAN)</option>
            <option value="Cazares (CAM)">Cazares (CAM)</option>
            <option value="Charles (INT)">Charles (INT)</option>
            <option value="Cuellar (FLA)">Cuellar (FLA)</option>
            <option value="D'Alessandro (INT)">D'Alessandro (INT)</option>
            <option value="Danielzinho (FLU)">Danielzinho (FLU)</option>
            <option value="David Terans (CAM)">David Terans (CAM)</option>
            <option value="De Arrascaeta (FLA)">De Arrascaeta (FLA)</option>
            <option value="Denilson (FLU)">Denilson (FLU)</option>
            <option value="Diego (FLA)">Diego (FLA)</option>
            <option value="Diego Pituca (SAN)">Diego Pituca (SAN)</option>
            <option value="Dodi (FLU)">Dodi (FLU)</option>
            <option value="Dodô (CAM)">Dodô (CAM)</option>
            <option value="Douglas (COR)">Douglas (COR)</option>
            <option value="Dudu (VAS)">Dudu (VAS)</option>
            <option value="Edenilson (INT)">Edenilson (INT)</option>
            <option value="Éderson (CRU)">Éderson (CRU)</option>
            <option value="Elias (CAM)">Elias (CAM)</option>
            <option value="Everton Felipe (SAO)">Everton Felipe (SAO)</option>
            <option value="Éverton Ribeiro (FLA)">Éverton Ribeiro (FLA)</option>
            <option value="Felipe Melo (PAL)">Felipe Melo (PAL)</option>
            <option value="Fellipe Bastos (VAS)">Fellipe Bastos (VAS)</option>
            <option value="Gabriel (COR)">Gabriel (COR)</option>
            <option value="Gabriel Calabres (SAN)">Gabriel Calabres (SAN)</option>
            <option value="Guerra (PAL)">Guerra (PAL)</option>
            <option value="Guilherme Costa (VAS)">Guilherme Costa (VAS)</option>
            <option value="Guilherme Nunes (SAN)">Guilherme Nunes (SAN)</option>
            <option value="Gustavo Blanco (CAM)">Gustavo Blanco (CAM)</option>
            <option value="Gustavo Bochecha (BOT)">Gustavo Bochecha (BOT)</option>
            <option value="Gustavo Ferrareis (BOT)">Gustavo Ferrareis (BOT)</option>
            <option value="Gustavo Scarpa (PAL)">Gustavo Scarpa (PAL)</option>
            <option value="Henrique (CRU)">Henrique (CRU)</option>
            <option value="Hernanes (SAO)">Hernanes (SAO)</option>
            <option value="Hudson (SAO)">Hudson (SAO)</option>
            <option value="Hugo Moura (FLA)">Hugo Moura (FLA)</option>
            <option value="Hyoran (PAL)">Hyoran (PAL)</option>
            <option value="Igor Gomes (SAO)">Igor Gomes (SAO)</option>
            <option value="Jadson (COR)">Jadson (COR)</option>
            <option value="Jadson (CRU)">Jadson (CRU)</option>
            <option value="Jair (CAM)">Jair (CAM)</option>
            <option value="Jean (BOT)">Jean (BOT)</option>
            <option value="Jean Lucas (FLA)">Jean Lucas (FLA)</option>
            <option value="Jean Pyerre (GRE)">Jean Pyerre (GRE)</option>
            <option value="Joao Paulo (BOT)">Joao Paulo (BOT)</option>
            <option value="Jose Welison (CAM)">Jose Welison (CAM)</option>
            <option value="Juan Alano (INT)">Juan Alano (INT)</option>
            <option value="Jucilei (SAO)">Jucilei (SAO)</option>
            <option value="Kaio (GRE)">Kaio (GRE)</option>
            <option value="Lincoln (GRE)">Lincoln (GRE)</option>
            <option value="Liziero (SAO)">Liziero (SAO)</option>
            <option value="Luan (SAO)">Luan (SAO)</option>
            <option value="Lucas Braga (SAN)">Lucas Braga (SAN)</option>
            <option value="Lucas Cândido (CAM)">Lucas Cândido (CAM)</option>
            <option value="Lucas Lima (PAL)">Lucas Lima (PAL)</option>
            <option value="Lucas Mineiro (VAS)">Lucas Mineiro (VAS)</option>
            <option value="Lucas Romero (CRU)">Lucas Romero (CRU)</option>
            <option value="Lucas Santos (VAS)">Lucas Santos (VAS)</option>
            <option value="Lucas Silva (CRU)">Lucas Silva (CRU)</option>
            <option value="Luiz Fernando (BOT)">Luiz Fernando (BOT)</option>
            <option value="Luiz Fernando (FLU)">Luiz Fernando (FLU)</option>
            <option value="Maicon (GRE)">Maicon (GRE)</option>
            <option value="Marcelo Mattos (VAS)">Marcelo Mattos (VAS)</option>
            <option value="Marcos Vinicius (BOT)">Marcos Vinicius (BOT)</option>
            <option value="Marquinhos (COR)">Marquinhos (COR)</option>
            <option value="Marquinhos (COR)">Marquinhos (COR)</option>
            <option value="Mateus Vital (COR)">Mateus Vital (COR)</option>
            <option value="Matheus Fernandes (PAL)">Matheus Fernandes (PAL)</option>
            <option value="Matheus Galdezani (INT)">Matheus Galdezani (INT)</option>
            <option value="Matheus Henrique (GRE)">Matheus Henrique (GRE)</option>
            <option value="Michel (GRE)">Michel (GRE)</option>
            <option value="Moises (PAL)">Moises (PAL)</option>
            <option value="Montoya (GRE)">Montoya (GRE)</option>
            <option value="Nathan (CAM)">Nathan (CAM)</option>
            <option value="Nene (SAO)">Nene (SAO)</option>
            <option value="Patrick (INT)">Patrick (INT)</option>
            <option value="Pedrinho (COR)">Pedrinho (COR)</option>
            <option value="Piris da Motta (FLA)">Piris da Motta (FLA)</option>
            <option value="Rafael Bilu (COR)">Rafael Bilu (COR)</option>
            <option value="Rafinha (CRU)">Rafinha (CRU)</option>
            <option value="Ralf (COR)">Ralf (COR)</option>
            <option value="Ramiro (COR)">Ramiro (COR)</option>
            <option value="Raphael Veiga (PAL)">Raphael Veiga (PAL)</option>
            <option value="Raul (VAS)">Raul (VAS)</option>
            <option value="Rene Junior (COR)">Rene Junior (COR)</option>
            <option value="Richard (COR)">Richard (COR)</option>
            <option value="Richard (INT)">Richard (INT)</option>
            <option value="Rickson (BOT)">Rickson (BOT)</option>
            <option value="Rithely (INT)">Rithely (INT)</option>
            <option value="Robinho (CRU)">Robinho (CRU)</option>
            <option value="Rodrigo Dourado (INT)">Rodrigo Dourado (INT)</option>
            <option value="Rodrigo Fernandes (VAS)">Rodrigo Fernandes (VAS)</option>
            <option value="Rodrigo Lindoso (INT)">Rodrigo Lindoso (INT)</option>
            <option value="Romulo (GRE)">Romulo (GRE)</option>
            <option value="Ronaldo (FLA)">Ronaldo (FLA)</option>
            <option value="Sarrafiore (INT)">Sarrafiore (INT)</option>
            <option value="Sornoza (COR)">Sornoza (COR)</option>
            <option value="Soteldo (SAN)">Soteldo (SAN)</option>
            <option value="Thaciano (GRE)">Thaciano (GRE)</option>
            <option value="Thiago Galhardo (VAS)">Thiago Galhardo (VAS)</option>
            <option value="Thiago Neves (CRU)">Thiago Neves (CRU)</option>
            <option value="Thiago Santos (PAL)">Thiago Santos (PAL)</option>
            <option value="Thiaguinho (COR)">Thiaguinho (COR)</option>
            <option value="Thonny Anderson (GRE)">Thonny Anderson (GRE)</option>
            <option value="Valdivia (INT)">Valdivia (INT)</option>
            <option value="Valencia (BOT)">Valencia (BOT)</option>
            <option value="Vinícius (CAM)">Vinícius (CAM)</option>
            <option value="Wenderson (BOT)">Wenderson (BOT)</option>
            <option value="Willian Arao (FLA)">Willian Arao (FLA)</option>
            <option value="Willian Farias (SAO)">Willian Farias (SAO)</option>
            <option value="Willian Maranhao (VAS)">Willian Maranhao (VAS)</option>
            <option value="Yan Sasse (VAS)">Yan Sasse (VAS)</option>
            <option value="Yuri (SAN)">Yuri (SAN)</option>
            <option value="Ze Rafael (PAL)">Ze Rafael (PAL)</option>
            <option value="Ze Ricardo (FLU)">Ze Ricardo (FLU)</option>
          </select>
        </p>
        <p>
          <select name="jog9" class="jog9" required>
            <option value="" selected="selected"></option>
            <option value="Pablo (SAO)">Pablo (SÃO)</option>
            <option value="Guerrero (INT)" >Guerrero (INT)</option>
            <option value="Sasha (SAN)" >Sasha (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog10" class="jog10" required>
            <option value="" selected="selected" ></option>
            <option value="Pablo (SAO)">Pablo (SÃO)</option>
            <option value="Guerrero (INT)" >Guerrero (INT)</option>
            <option value="Sasha (SAN)" >Sasha (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog11" class="jog11" required>
            <option value="" selected="selected"></option>
            <option value="Pablo (SÃO)">Pablo (SÃO)</option>
            <option value="Guerrero (INT)" >Guerrero (INT)</option>
            <option value="Sasha (SAN)" >Sasha (SAN)</option>
          </select>
        </p>
      </div> 
      <div class="img_banco">
        <img class="logo_time" src="imagens/<?php echo $_SESSION['imgtime']; ?>" alt="time">
        <img class="banco_reserva" src="img/banco.png" alt="reservas">
        <h1 class="nome_time"><?php echo $_SESSION['time'];?></h1>
        <h1 class="nome_tecnico"><?php echo $_SESSION['nome'];?></h1>
        <p>
          <select name="res1" class="res1" required>
              <option value="" selected="selected"></option>
              <option value="T. Volpi (SÃO)">T. Volpi (SÃO)</option>
              <option value="M. Lomba (INT)">M. Lomba (INT)</option>
              <option value="Everson (SAN)">Everson (SAN)</option>
          </select>
        </p>
        <p>
          <select name="res2" class="res2" required>
              <option value="" selected="selected"></option>
              <option value="B. Alves (SÃO)">B. Alves (SÃO)</option>
              <option value="Cuesta (INT)" >Cuesta (INT)</option>
              <option value="G. Henrique (SAN)" >G. Henrique (SAN)</option>
          </select>
        </p>
        <p>
          <select name="res3" class="res3" required>
              <option value="" selected="selected"></option>
              <option value="D. Alves (SÃO)">D. Alves (SÃO)</option>
              <option value="Bruno (INT)">Bruno (INT)</option>
              <option value="V. Ferraz (SAN)">V. Ferraz (SAN)</option>
          </select>
        </p>
        <p>
          <select name="res4" class="res4" required>
              <option value="" selected="selected"></option>
              <option value="Hernanes (SÃO)">Hernanes (SÃO)</option>
              <option value="Dalessandro (INT)">Dalessandro (INT)</option>
              <option value="C. Sanchez (SAN)" >C. Sanchez (SAN)</option>
          </select>
        </p>
        <p>
          <select name="res5" class="res5" required>
              <option value="" selected="selected"></option>
              <option value="Pablo (SÃO)">Pablo (SÃO)</option>
              <option value="Guerrero (INT)" >Guerrero (INT)</option>
              <option value="Sasha (SAN)">Sasha (SAN)</option>
          </select>
        </p>
        
        </p>
        <input class="btn-enviar" type="submit" value="Enviar" >
      </div>
      <p>
          <select name="formacao" class="formacao" onChange="redirectPage(this.value)" required>
              <option value="4-3-3" selected>4-3-3</option>
              <option value="4-4-2">4-4-2</option>
              <option value="3-5-2" >3-5-2</option>
          </select>
    </form>
    </div> 
    <a href="<?php echo $dado['formacao'];?>recept.php">Ir para escalação!</a>       
    <?php
    } else {
      ?>
      
      <div class="corpo_form-cad">
    <h1>Escale seu time</h1>
    <form method="POST" action="process_escal.php">
      <img class="campo_escalacao" src="img/campo_escalacao.png" alt="campo">
      <div class="escalacao_completa">
        <p>
          <select name="jog1" class="jog1" required>
            <option value="" selected="selected"></option>
            <option value="T. Volpi (SAO)">T. Volpi (SÃO)</option>
            <option value="M. Lomba (INT)">M. Lomba (INT)</option>
            <option value="Everson (SAN)">Everson (SAN)</option>
          </select>
        </p>
          
        <p>
          <select name="jog2" class="jog2" required>
            <option value="" selected="selected"></option>
            <option value="B. Alves (SAO)">B. Alves (SÃO)</option>
            <option value="Cuesta (INT)" >Cuesta (INT)</option>
            <option value="G. Henrique (SAN)" >G. Henrique (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog3" class="jog3" required>
            <option value="" selected="selected"></option>
            <option value="B. Alves (SAO)">B. Alves (SÃO)</option>
            <option value="Cuesta (INT)" >Cuesta (INT)</option>
            <option value="G. Henrique (SAN)" >G. Henrique (SAN)</option>
          </select>
        </p>
        
        <p>
          <select name="jog4" class="jog4" required>
            <option value="" selected="selected"></option>
            <option value="D. Alves (SAO)">D. Alves (SÃO)</option>
            <option value="Bruno (INT)">Bruno (INT)</option>
            <option value="V. Ferraz (SAN)" >V. Ferraz (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog5" class="jog5" required>
            <option value="" selected="selected"></option>
            <option value="D. Alves (SAO)">D. Alves (SÃO)</option>
            <option value="Bruno (INT)">Bruno (INT)</option>
            <option value="V. Ferraz (SAN)">V. Ferraz (SAN)</option>
          </select>
        </p>
        
        <p>
          <select name="jog6" class="jog6" required>
            <option value="" selected="selected"></option>
            <option value="Hernanes (SAO)">Hernanes (SÃO)</option>
            <option value="Dalessandro (INT)">Dalessandro (INT)</option>
            <option value="C. Sanchez (SAN)">C. Sanchez (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog7" class="jog7" required>
            <option value="" selected="selected" ></option>
            <option value="Hernanes (SAO)">Hernanes (SÃO)</option>
            <option value="Dalessandro (INT)">Dalessandro (INT)</option>
            <option value="C. Sanchez (SAN)">C. Sanchez (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog8" class="jog8" required>
            <option value="" selected="selected"></option>
            <option value="Hernanes (SAO)">Hernanes (SÃO)</option>
            <option value="Dalessandro (INT)">Dalessandro (INT)</option>
            <option value="C. Sanchez (SAN)">C. Sanchez (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog9" class="jog9" required>
            <option value="" selected="selected"></option>
            <option value="Pablo (SAO)">Pablo (SÃO)</option>
            <option value="Guerrero (INT)" >Guerrero (INT)</option>
            <option value="Sasha (SAN)" >Sasha (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog10" class="jog10" required>
            <option value="" selected="selected" ></option>
            <option value="Pablo (SAO)">Pablo (SÃO)</option>
            <option value="Guerrero (INT)" >Guerrero (INT)</option>
            <option value="Sasha (SAN)" >Sasha (SAN)</option>
          </select>
        </p>
        <p>
          <select name="jog11" class="jog11" required>
            <option value="" selected="selected"></option>
            <option value="Pablo (SÃO)">Pablo (SÃO)</option>
            <option value="Guerrero (INT)" >Guerrero (INT)</option>
            <option value="Sasha (SAN)" >Sasha (SAN)</option>
          </select>
        </p>
      </div> 
      <div class="img_banco">
        <img class="logo_time" src="imagens/<?php echo $_SESSION['imgtime']; ?>" alt="time">
        <img class="banco_reserva" src="img/banco.png" alt="reservas">
        <h1 class="nome_time"><?php echo $_SESSION['time'];?></h1>
        <h1 class="nome_tecnico"><?php echo $_SESSION['nome'];?></h1>
        <p>
          <select name="res1" class="res1" required>
              <option value="" selected="selected"></option>
              <option value="T. Volpi (SÃO)">T. Volpi (SÃO)</option>
              <option value="M. Lomba (INT)">M. Lomba (INT)</option>
              <option value="Everson (SAN)">Everson (SAN)</option>
          </select>
        </p>
        <p>
          <select name="res2" class="res2" required>
              <option value="" selected="selected"></option>
              <option value="B. Alves (SÃO)">B. Alves (SÃO)</option>
              <option value="Cuesta (INT)" >Cuesta (INT)</option>
              <option value="G. Henrique (SAN)" >G. Henrique (SAN)</option>
          </select>
        </p>
        <p>
          <select name="res3" class="res3" required>
              <option value="" selected="selected"></option>
              <option value="D. Alves (SÃO)">D. Alves (SÃO)</option>
              <option value="Bruno (INT)">Bruno (INT)</option>
              <option value="V. Ferraz (SAN)">V. Ferraz (SAN)</option>
          </select>
        </p>
        <p>
          <select name="res4" class="res4" required>
              <option value="" selected="selected"></option>
              <option value="Hernanes (SÃO)">Hernanes (SÃO)</option>
              <option value="Dalessandro (INT)">Dalessandro (INT)</option>
              <option value="C. Sanchez (SAN)" >C. Sanchez (SAN)</option>
          </select>
        </p>
        <p>
          <select name="res5" class="res5" required>
              <option value="" selected="selected"></option>
              <option value="Pablo (SÃO)">Pablo (SÃO)</option>
              <option value="Guerrero (INT)" >Guerrero (INT)</option>
              <option value="Sasha (SAN)">Sasha (SAN)</option>
          </select>
        </p>
        
        </p>
        <input class="btn-enviar" type="submit" value="Enviar" >
      </div>
      <p>
          <select name="formacao" class="formacao" onChange="redirectPage(this.value)" required>
              <option value="4-3-3" selected>4-3-3</option>
              <option value="4-4-2">4-4-2</option>
              <option value="3-5-2" >3-5-2</option>
          </select>
    </form>
    </div> <?php } ?>

    <a href="sair.php" class="logout">Logout</a>
</body>
<footer>
   <?php
   require_once 'footer.php';
   ?> 
</footer>
</html>