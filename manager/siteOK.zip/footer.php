
<footer>
	
	<p class="footer">&copy manager 2.0</p>
		<a href="https://api.whatsapp.com/send?1=pt_BR&phone=5581997640170">
        	<img src="img/whats.png" alt="whatsapp" class="whats">

</footer>
