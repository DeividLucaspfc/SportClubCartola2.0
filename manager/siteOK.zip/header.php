<header class="cabecalho">
    <a href="index.php"><h1 class="logo"></h1></a>
    <button class="btn-menu">&#9660;</button>
    <nav class="menu">
      <a class="btn-close">&#9650;</a>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="4-3-3.php">Escalar</a></li>
        <li><a href="acompanhar.php">Acompanhar</a></li>
        <li><a href="cadastrar.php">Inscrever-se</a></li>
        <li><a href="#">Quem somos</a></li>
      </ul>
    </nav>
  </header>
  <script
  src="https://code.jquery.com/jquery-3.4.1.js"
  integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
  crossorigin="anonymous"></script>
  <script>
    $(".btn-menu").click(function(){
      $(".menu").show();
    });
    $(".btn-close").click(function(){
      $(".menu").hide();
    });
  </script>
    
    