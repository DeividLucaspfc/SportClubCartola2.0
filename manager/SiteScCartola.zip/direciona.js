function redirectPage(v){
    document.location.href =v+'.php';
}