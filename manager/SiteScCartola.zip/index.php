<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="Sport Club Cartola, Desenvolvimento de Jogos e Campeonatos.">
    <meta name="theme-color" content="#099e6e">
    <meta name="keywords" content="cartola, campeonatos, manager, sites">
    <meta name="robots" content= "index, follow">
    <link href="https://fonts.googleapis.com/css?family=Cairo&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon"/>
    <link rel="stylesheet" href="4_3_3.css">
    <script src="direciona.js"></script>
</head>
<body>
  <?php require_once 'header.php';
  
  ?>
  <div id="demo" style="color: orange; text-align: center; font-size: 20pt;">
 	
 </div>

 <script>
 	/**Mostra hora alternando em JS**/
 	var myVar = setInterval(myTimer ,1000);
    function myTimer() {
        var d = new Date(), displayDate;
       if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
          displayDate = d.toLocaleTimeString('pt-BR');
       } else {
          displayDate = d.toLocaleTimeString('pt-BR', {timeZone: 'America/Recife'});
       }
          document.getElementById("demo").innerHTML = displayDate;
    }
 </script>
 
 
  <h1>SEJA BEM VINDO AO SPORT CLUB CARTOLA!</h1>
  <h3>Aqui você joga cartola o ano todo!</h3>
  <a href="login.php" class="loginhome">Efetue login para acesso restrito!</a> <br> <br>
  <a href="https://drive.google.com/uc?authuser=0&id=15BhM4rbtJal7KGjltJUg92b9T27npU00&export=download" id="app">  Faça download do app SCC clicando AQUI  </a> <br> <br> <br> <br>
  
</body>
<footer></footer>
   <?php
   require_once 'footer.php';
   ?> 
</footer>
</html>